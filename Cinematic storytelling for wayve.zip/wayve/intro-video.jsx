// Wayve intro film — 1080×1920 Instagram Reel, single retimable scene with baked soundtrack
const { SceneStage, useScene, VideoSprite, TweaksPanel, TweakSection, TweakToggle, useTweaks, clamp } = window;

const OFFWHITE = '#fbfbf9', INK = '#0f0e0c';
const serif = "'Noto Serif KR', serif";
const instr = "'Instrument Serif', serif";
const sans = "'Pretendard Variable', Pretendard, sans-serif";

const fu = (t, t0, d = 0.8, dy = 22) => {
  const p = clamp((t - t0) / d, 0, 1);
  const e = 1 - Math.pow(1 - p, 3);
  return { opacity: e, transform: `translateY(${(1 - e) * dy}px)` };
};

const BEATS = (() => {
  const g = [1.0, 0.95, 0.85, 0.75, 0.65, 0.6, 0.55, 0.5, 0.5, 0.48, 0.46];
  let t = 8; const out = [];
  g.forEach(x => { t += x; out.push(t); });
  return out;
})();

const Q = 'So, what do you think?';

function IntroScene() {
  const { localTime: t } = useScene();
  const chars = clamp(Math.floor((t - 5.0) / 0.065), 0, Q.length);
  let pulse = 1;
  for (const b of BEATS) { const p = (t - b) / 0.18; if (p > 0 && p < 1) pulse = 1 + 0.05 * Math.sin(p * Math.PI); }
  const caretOn = Math.floor(t * 2) % 2 === 0;
  const seg = (a, b) => t >= a && t < b;
  const vign = clamp((t - 20.4) / 2.2, 0, 1);
  const center = { position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 80px', textAlign: 'center' };
  return (
    <div data-screen-label={'Intro ' + Math.floor(t) + 's'} style={{ position: 'absolute', inset: 0, background: INK, color: OFFWHITE, overflow: 'hidden', fontFamily: sans, wordBreak: 'keep-all' }}>
      <VideoSprite src="wayve/assets/audio/intro-soundtrack.wav" start={0} end={24} style={{ position: 'absolute', width: 2, height: 2, opacity: 0 }} />
      {seg(0, 4.9) && (
        <div style={{ ...center, gap: 48, opacity: 1 - clamp((t - 4.3) / 0.5, 0, 1) }}>
          <div style={{ fontFamily: serif, fontSize: 62, fontWeight: 400, lineHeight: 1.5, color: 'rgba(251,251,249,0.85)', ...fu(t, 0.4) }}>영어, 오래 공부했습니다.</div>
          <div style={{ fontFamily: serif, fontSize: 62, fontWeight: 400, lineHeight: 1.5, color: 'rgba(251,251,249,0.85)', ...fu(t, 2.3) }}>단어장 몇 권,<br />시험 점수도 충분한데 —</div>
        </div>
      )}
      {seg(4.3, 8.0) && (
        <div style={center}>
          <div style={{ fontSize: 27, fontWeight: 600, letterSpacing: '0.22em', color: 'rgba(251,251,249,0.4)', marginBottom: 60, ...fu(t, 4.5, 0.6) }}>그때, 누군가 물었습니다</div>
          <div style={{ fontFamily: instr, fontStyle: 'italic', fontSize: 84, lineHeight: 1.3, minHeight: '2.6em' }}>&ldquo;{Q.slice(0, chars)}<span style={{ opacity: caretOn ? 1 : 0 }}>|</span>&rdquo;</div>
          <div style={{ fontSize: 32, color: 'rgba(251,251,249,0.5)', marginTop: 56, ...fu(t, 6.2) }}>그래서… 어떻게 생각하세요?</div>
        </div>
      )}
      {seg(8.0, 17.2) && (
        <div style={center}>
          <div style={{ fontFamily: instr, fontStyle: 'italic', fontSize: 84, lineHeight: 1.3, color: 'rgba(251,251,249,0.18)', transform: `scale(${pulse})` }}>&ldquo;So, what do you think?&rdquo;</div>
          <div style={{ fontSize: 30, letterSpacing: '0.12em', color: 'rgba(251,251,249,0.45)', marginTop: 66, minHeight: '1.6em', ...fu(t, 10.6) }}>모두가 기다립니다.</div>
          <div style={{ fontFamily: serif, fontSize: 74, fontWeight: 700, marginTop: 66, ...fu(t, 13.2, 1.2) }}>머릿속이, 하얘집니다.</div>
        </div>
      )}
      {seg(17.2, 20.4) && (
        <div style={{ ...center, gap: 52 }}>
          <div style={{ fontFamily: serif, fontSize: 60, fontWeight: 400, lineHeight: 1.5, color: 'rgba(251,251,249,0.7)', ...fu(t, 17.3, 1.0) }}>공부가 부족해서가 아닙니다.</div>
          <div style={{ fontFamily: serif, fontSize: 76, fontWeight: 900, lineHeight: 1.4, ...fu(t, 18.6, 1.0) }}>말할 기회가<br />드물었을 뿐입니다.</div>
        </div>
      )}
      {t >= 20.4 && (
        <div style={center}>
          <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at center, rgba(0,0,0,0.15) 25%, rgba(0,0,0,0.8) 100%)', opacity: vign, pointerEvents: 'none' }} />
          <div style={{ position: 'relative', ...fu(t, 20.6, 1.4) }}>
            <img src="wayve/assets/img-01.png" alt="WAYVE" style={{ height: 64, filter: 'invert(1)' }} />
            <div style={{ fontFamily: instr, fontStyle: 'italic', fontSize: 40, color: 'rgba(251,251,249,0.55)', marginTop: 44 }}>Read less. Speak more.</div>
            <div style={{ fontSize: 26, fontWeight: 600, letterSpacing: '0.14em', color: 'rgba(251,251,249,0.35)', marginTop: 56, ...fu(t, 22.2, 1.0) }}>@wayve.kr</div>
          </div>
        </div>
      )}
    </div>
  );
}

function CtaScene() {
  const { localTime: t } = useScene();
  const center = { position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 80px', textAlign: 'center' };
  return (
    <div data-screen-label={'CTA ' + Math.floor(t) + 's'} style={{ position: 'absolute', inset: 0, background: INK, color: OFFWHITE, overflow: 'hidden', fontFamily: sans, wordBreak: 'keep-all' }}>
      <div style={center}>
        <div style={{ fontSize: 27, fontWeight: 600, letterSpacing: '0.2em', color: 'rgba(251,251,249,0.4)', ...fu(t, 0.15, 0.7) }}>지금 시작할 준비가 됐나요?</div>
        <div style={{ fontFamily: serif, fontSize: 88, fontWeight: 900, lineHeight: 1.3, marginTop: 44, ...fu(t, 0.5, 0.9) }}>당신의 길을<br /><em style={{ fontFamily: instr, fontStyle: 'italic', fontWeight: 400 }}>열어가세요.</em></div>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 16, background: '#FEE500', color: '#2B1600', fontSize: 36, fontWeight: 700, padding: '30px 64px', borderRadius: 99, marginTop: 84, ...fu(t, 1.3, 0.9) }}>
          <svg width="38" height="38" viewBox="0 0 24 24" fill="#2B1600"><path d="M12 3C6.48 3 2 6.54 2 10.9c0 2.8 1.86 5.26 4.66 6.66-.15.52-.96 3.32-.99 3.54 0 0-.02.17.09.23.11.06.24.01.24.01.32-.04 3.66-2.4 4.24-2.81.57.08 1.16.13 1.76.13 5.52 0 10-3.54 10-7.9S17.52 3 12 3z"/></svg>
          카카오톡으로 시작하기
        </div>
        <div style={{ fontSize: 28, letterSpacing: '0.04em', color: 'rgba(251,251,249,0.45)', marginTop: 40, ...fu(t, 1.9, 0.8) }}>pf.kakao.com/_xaHXsX</div>
        <div style={{ fontSize: 26, fontWeight: 600, letterSpacing: '0.14em', color: 'rgba(251,251,249,0.35)', marginTop: 72, ...fu(t, 2.3, 0.8) }}>인스타그램 @wayve.kr</div>
      </div>
    </div>
  );
}

function WayveIntroFilm() {
  const [tw, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  return (
    <div style={{ minHeight: '100vh', background: '#08090b', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <SceneStage width={1080} height={1920} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK} bg="#0f0e0c">
        {{ Intro: IntroScene, CTA: CtaScene }}
      </SceneStage>
      <TweaksPanel>
        <TweakSection label="Timeline" />
        <TweakToggle label="Motion editor" value={tw.motionEditor} onChange={v => setTweak('motionEditor', v)} />
      </TweaksPanel>
    </div>
  );
}
window.WayveIntroFilm = WayveIntroFilm;